function [lines] = myHoughLineSegments(lineRho, lineTheta, Im)
