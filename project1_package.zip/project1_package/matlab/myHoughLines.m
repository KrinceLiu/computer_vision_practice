function [rhos, thetas] = myHoughLines(H, nLines)
%Your implemention here

end
        