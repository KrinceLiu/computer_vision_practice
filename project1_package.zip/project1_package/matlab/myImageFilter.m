function [img1] = myImageFilter(img0, h)

end
