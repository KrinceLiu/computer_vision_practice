% Your solution to Q2.1.5 goes here!

%% Read the image and convert to grayscale, if necessary

%% Compute the features and descriptors

for i = 0:36
    %% Rotate image
    
    %% Compute features and descriptors
    
    %% Match features
    
    %% Update histogram
end

%% Display histogram