function [H2to1] = computeH_norm(x1, x2)

%% Compute centroids of the points
centroid1 = ;
centroid2 = ;

%% Shift the origin of the points to the centroid

%% Normalize the points so that the average distance from the origin is equal to sqrt(2).

%% similarity transform 1
T1 = [];

%% similarity transform 2
T2 = [];

%% Compute Homography

%% Denormalization
H2to1 = ;
