function [ locs1, locs2] = matchPics( I1, I2 )
%MATCHPICS Extract features, obtain their descriptors, and match them!

%% Convert images to grayscale, if necessary

%% Detect features in both images

%% Obtain descriptors for the computed feature locations

%% Match features using the descriptors

end

