% A test script using templeCoords.mat
%
% Write your code here
%

% save extrinsic parameters for dense reconstruction
save('../data/extrinsics.mat', 'R1', 't1', 'R2', 't2');
